#Requires AutoHotkey v2.0
#SingleInstance Force
Persistent

; ================================================================
; ★ スリープ復帰から何分後に自動起動するか
; ================================================================
delayMinutes := 30

; ================================================================
; ★ スリープ時間がこの値（時間）以上の場合のみ起動
;    例: 6 なら、6時間以上スリープしていた場合のみ起動（就寝明け判定）
; ================================================================
minSleepHours := 6

; ================================================================
; ★ 自動起動をスキップする曜日
;    A_WDay の値: 1=日, 2=月, 3=火, 4=水, 5=木, 6=金, 7=土
;    例: [7] なら土曜スキップ / [1, 7] なら土日スキップ
; ================================================================
skipWDays := [7]

; ================================================================
; ★ lock_window.ahk のパス
;    このファイルと同じフォルダに置いている場合は変更不要です。
; ================================================================
scriptPath   := A_ScriptDir "\lock_window.ahk"
sleepLogPath := A_ScriptDir "\last_sleep.txt"

; ================================================================
; ★ 複数プロセスからの同時アクセス対策（変更不要）
;
;    current_phase.txt・work_goal.txt・overtime_work.txt・day_state.txt は
;    lock_window.ahk と launcher.ahk の両方から読み書きされる共有ファイル。
;    お互い独立したプロセスなので、書き込み中のファイルを別プロセスが
;    ちょうど同時に読もうとする（あるいはその逆）と、Windowsのファイル共有
;    違反（エラー32「別のプロセスが使用中です」）が発生することがある。
;    通常は一瞬で解消される一時的な競合なので、短い待機を挟んで
;    数回リトライすることで対処する（lock_window.ahk側にも同じ実装がある）。
; ================================================================
SafeReadFile(path, retries := 5, delayMs := 30) {
    loop retries {
        try
            return FileRead(path)
        catch {
            Sleep(delayMs)
        }
    }
    return ""
}

SafeDeleteFile(path, retries := 5, delayMs := 30) {
    loop retries {
        try {
            FileDelete(path)
            return true
        } catch {
            Sleep(delayMs)
        }
    }
    return false
}

SafeWriteFile(path, content, retries := 5, delayMs := 30) {
    loop retries {
        SafeDeleteFile(path, 1, 0)   ; 無ければ無いで良いので1回だけ試して失敗は無視
        try {
            FileAppend(content, path)
            return true
        } catch {
            Sleep(delayMs)
        }
    }
    return false
}

; ================================================================
; ★ 睡眠ベースの「1日の区切り」（day_state.txt）
;
;    作業ノルマ・残業時間の判定は、カレンダー上の日付（0時）ではなく
;    ここで管理する「dayId」という通し番号を基準にする。
;    dayId は StartWakeRoutine()（＝スリープ復帰・長時間無操作からの復帰・
;    手動でのスリープ解除ルーティン実行のいずれか）が呼ばれるたびに
;    1つ進む。つまり「しっかり寝て起きるまでは同じ1日」という扱いになり、
;    深夜0時をまたいで作業を続けても、その日の続きとして正しく計測される。
;
;    dayId は day_state.txt（このファイルと同じフォルダ）に保存し、
;    lock_window.ahk 側からも読み取れるようにする。書き込むのは
;    launcher.ahk のみ（lock_window.ahk は起動時に読み取るだけ）。
;
;    work_goal.txt（作業ノルマ）・overtime_work.txt（残業時間）は
;    どちらもこの dayId を日付の代わりに使う。それ以外の「1日1回」系
;    （運動・昼休みボタン、ゲームプレイ時間制限など）は今回の変更対象外で、
;    従来通りカレンダー日付のままなので注意。
; ================================================================
dayStatePath := A_ScriptDir "\day_state.txt"

global currentDayId := 1
if FileExist(dayStatePath) {
    _dayStateRaw := Trim(SafeReadFile(dayStatePath))
    if (_dayStateRaw != "")
        try currentDayId := Integer(_dayStateRaw)
} else {
    SafeWriteFile(dayStatePath, currentDayId)
}

; ================================================================
; ★ 食事休憩の時間設定（lock_window.ahk と合わせてください）
;    この時間帯にカウントダウンが終了した場合、クロッキーは
;    食事休憩終了後まで自動的に待機します。
; ================================================================
mealPauseStartH := 19
mealPauseStartM := 0
mealPauseEndH   := 20
mealPauseEndM   := 30

; ================================================================
; ★ 残業時間の計測（ロック外での作業ノルマ超過分）
;
;    lock_window.ahk はノルマ達成後、休憩中にスクリプトを終了して
;    1日を終える運用を想定しているため、終了後にロック外で行った
;    追加の作業時間はそちらでは計測できません。
;    そのぶんをこの launcher.ahk が常駐監視で独自に計測し、
;    翌日のノルマ軽減（lock_window.ahk 側の繰り越し計算）に
;    加算されるようにします。
;
;    overtimeWorkWindowTitles / overtimeWorkWindowProcesses
;      → lock_window.ahk の workWindowTitles / workWindowProcesses と
;        必ず同じ内容にしてください（判定基準がずれると正しく計測できません）
;
;    overtimeIdleToleranceSecs
;      → lock_window.ahk の workIdleToleranceSecs と合わせてください
;
;    計測条件（すべて満たす間だけ加算）:
;      ・本日すでにノルマを達成している（work_goal.txt を参照）
;      ・現在 lock_window.ahk が lock / 中休み フェーズ中ではない
;        （その間は lock_window.ahk 側で計測済みのため、二重計上防止）
;      ・対象ウィンドウがアクティブ、かつ無操作許容時間内
; ================================================================
overtimeWorkWindowTitles := [
    ; ↓ lock_window.ahk の workWindowTitles と合わせて編集
    ; "Visual Studio Code",
    ; "sakura",
]
overtimeWorkWindowProcesses := [
    "CLIPStudioPaint.exe",
    ; ↓ lock_window.ahk の workWindowProcesses と合わせて編集
    ; "sai2.exe",
    ; "Photoshop.exe",
]
overtimeIdleToleranceSecs := 60   ; 1分

; 翌日のノルマ予測表示（トレイツールチップ）にも使うため、
; lock_window.ahk の同名設定と必ず同じ値にしてください
totalWorkGoalMinutes := 150   ; 2時間半
workGoalMinMinutes   := 90    ; 1時間30分（超過繰り越しによる下限）

; ===== 残業ログ・作業ノルマログのパス（lock_window.ahk と共有・変更不要）=====
overtimeLogPath := A_ScriptDir "\overtime_work.txt"
workGoalLogPath := A_ScriptDir "\work_goal.txt"

; ================================================================
; ★ クロッキー設定
;
;    croquisMode
;      → 使用するモードを番号で指定してください
;
;        1 … 25分 × 1枚
;        2 … 15分 × 2枚（セット間に2分休憩）
;        3 …  5分 × 5枚（セット間に1分休憩）
;        4 … 15分 × 2枚相当（モード2と同じ時間割だが、2セット目は画像を選ばない。
;            1セット目のモデルを記憶を頼りに描く練習用）
;        5 … 60分 × 1枚相当だが画像を使わない教本模写用（開始前に5分の準備時間）
;        7 … モード5と同じ（画像不要の教本模写）だがタイマーが30分の短縮版
;        0 … ランダムモード（起動のたびに1〜5・7のいずれかをランダムに選択）（デフォルト）
;
;    croquisRandomExcludeModes
;      → ランダムモード（croquisMode = 0）のとき、選択肢から除外したいモード番号を
;        配列で指定します。例: [4] ならモード4は絶対に選ばれません
;
;    croquisModeParams の folder
;      → モードごとのモデル画像フォルダのパス。
;        モード1は croquis_models_1、モード2は croquis_models_2、
;        モード3は croquis_models_3 のように、モードごとに別フォルダから
;        ランダムに画像を選びます（フォルダは事前に作成し、画像を入れておくこと）
;        モード5・7は画像を使わないため空文字のままで構いません
;
;    croquisModeParams の interSecs
;      → セットとセットの間の待機時間（秒）だけでなく、【最初のセットが
;        始まる前の待機時間】としても使われます（クリップボードにコピー済みの
;        画像をサブビューに貼り付ける時間、またはモード5・7の場合は教本を
;        開く準備時間）。セットが1つしかないモード（1・5・7）でも、この値が
;        そのまま最初の待機時間として使われるので 0 のままにしないこと
;
;    croquisDelayMinutes
;      → スリープ復帰後、クロッキー開始までの待機時間（分）
;
;    croquisUsedLog / croquisShotDir
;      → 変更不要
; ================================================================
croquisMode := 0
croquisRandomExcludeModes := [2]   ; 例: [4] と書けばモード4をランダム対象から除外
croquisDelayMinutes := 5
croquisUsedLog      := A_ScriptDir "\croquis_used.txt"   ; 全モード共通の使用済みリスト（1ファイルで一元管理）
croquisShotDir      := A_ScriptDir "\croquis_shots"   ; lock_window.ahk と合わせること
croquisModeCyclePath := A_ScriptDir "\croquis_mode_cycle.txt"   ; ランダムモードの「一周するまで被りなし」用（変更不要）
croquisSchedulePath  := A_ScriptDir "\croquis_schedule.txt"   ; 週間スケジュール（mode_scheduler.ahk で保存・変更不要）

; モード別パラメータ（フォルダもここでモードごとに指定）
croquisModeParams := Map(
    1, {lockSecs: 1500, sets: 1, interSecs:  60, folder: A_ScriptDir "\croquis_models_1"},
    2, {lockSecs:  900, sets: 2, interSecs: 120, folder: A_ScriptDir "\croquis_models_2"},
    3, {lockSecs:  300, sets: 5, interSecs:  60, folder: A_ScriptDir "\croquis_models_3"},
    ; モード4：時間割はモード2と同じ（15分×2セット）。1セット目は通常どおり画像を見て描き、
    ; 2セット目は新しい画像を選ばず、1セット目のモデルを記憶を頼りに描く練習用モード。
    ; そのため画像プールはモード2と共用（croquis_models_2）でよい。
    4, {lockSecs:  900, sets: 2, interSecs: 120, folder: A_ScriptDir "\croquis_models_2"},
    ; モード5：教本の模写用。画像は一切使わないため folder は空文字。
    ; 文章を読みながらの作業になり通常のクロッキーより時間がかかるため60分に設定。
    ; interSecs（5分）は開始前に教本を開く準備時間として使う。
    5, {lockSecs: 3600, sets: 1, interSecs: 300, folder: ""},
    ; モード7：モード5と全く同じ（教本の模写・画像不要）だが、タイマーが30分の短縮版。
    7, {lockSecs: 1800, sets: 1, interSecs: 300, folder: ""}
)

; ================================================================
; ★ クロッキー週次レポート設定
;
;    croquisReportWebhook
;      → 送信先の Discord Webhook URL
;        サボり通知とは別のチャンネルに送りたい場合は別のURLを設定
;        同じでよければ下の discordWebhook と同じURLを入れてください
;
;    croquisReportWDay
;      → 送信する曜日（A_WDay: 1=日, 2=月, 3=火, 4=水, 5=木, 6=金, 7=土）
;        土曜 = 7
;
;    croquisReportHour
;      → 送信する時刻（時・24時間表記）
; ================================================================
croquisReportWebhook := "https://discord.com/api/webhooks/1514960540949282948/QWx9sLWEDVBct8MUXU5EvsgiGKcY5C3BRriVil5Ye_yM2hvCKJPfFdI-MryZNVmhDXBS?thread_id=1514960461815353394"
croquisReportWDay    := 7    ; 土曜
croquisReportHour    := 15   ; 15時

; ================================================================
; ★ 就寝時スマホブロックの設定
;
;    nightBlockDelay … 就寝モード開始（トレイメニュー操作）から
;                       何分後にスマホをブロック＋PCをスリープさせるか
;
;    nextdns 系の値は lock_window.ahk と合わせてください。
; ================================================================
nightBlockDelay := 30

nextdnsApiKey   := "10fe27590862f3c7d0e62ca47fe93ec40bbd0b78"
nextdnsProfile  := "5f2c95"

nextdnsCategories := [
    "social-networks",
    "video-streaming",
    "gaming",
]
nextdnsServices := [
    "youtube",
    "twitter",
    "instagram",
    "tiktok",
    "facebook",
    "snapchat",
    "reddit",
    "twitch",
    "steam",
    "discord",
]
nextdnsBlockList := [
    ; ↓ lock_window.ahk の nextdnsBlockList と合わせて追記
]

; 就寝ブロックが実行されたことを示すフラグファイル（変更不要）
nightBlockFlagPath := A_ScriptDir "\night_block_flag.txt"

; ===== トレイアイコン設定（変更不要）=====
; スリープ復帰後、タスクバーのこのアイコンにマウスを乗せると
; 「作業開始まで XX:XX」という残り時間が常に表示されます。
A_IconTip := "Work Launcher - 待機中"

; ===== 就寝モード状態（変更不要）=====
nightModeActive  := false
nightModeEndTick := 0

; ===== カウントダウンGUI（変更不要）=====
; ※ GUIはモニター環境によって表示されない場合があります。
;    トレイアイコンのツールチップが確実な確認方法です。
cdGui := Gui("+AlwaysOnTop +ToolWindow", "Work Mode")
cdGui.SetFont("s9", "Segoe UI")
cdGui.BackColor := "1A1A2E"

cdLabel := cdGui.Add("Text", "x10 y10 w140 cWhite", "作業開始まで...")
cdGui.SetFont("s26 bold", "Segoe UI")
cdCount := cdGui.Add("Text", "x10 y28 w140 cWhite", "00:00")
cdGui.SetFont("s8", "Segoe UI")
cdSkipBtn := cdGui.Add("Button", "x158 y10 w72 h70", "今すぐ`n開始")
cdSkipBtn.OnEvent("Click", (*) => SkipCountdown())
cdGui.Show("Center w240 h120 NoActivate Hide")

; ===== スリープ復帰の検知（変更不要）=====
WM_POWERBROADCAST      := 0x0218
PBT_APMSUSPEND         := 0x4
PBT_APMRESUMEAUTOMATIC := 0x12

; ===== トレイメニュー（変更不要）=====
trayMenu := A_TrayMenu
trayMenu.Add()
trayMenu.Add("🌙 就寝モード開始 (" nightBlockDelay " 分後にスマホをブロック)", OnNightModeStart)
trayMenu.Add("🌙 就寝モードをキャンセル", OnNightModeCancel)
trayMenu.Add()
trayMenu.Add("🔁 スリープ解除ルーティンを手動実行 (" delayMinutes "分待機→クロッキー→作業)", OnManualWakeRoutine)
trayMenu.Add("🧪 右脳ドローイング（テスト実行）", OnFastCroquisTest)
trayMenu.Add("🚫 本日のクロッキーをスキップ", OnToggleSkipCroquis)

; ===== 本日のクロッキーをスキップ（変更不要）=====
; トレイメニューでいつでもON/OFFを切り替えられる。ONの間は LaunchCroquis() が
; 呼ばれても通常のクロッキー処理を全部飛ばし、直接作業タイマーを起動する
; （手動実行のスリープ解除ルーティンにも効く。右脳ドローイングのテスト実行は
;   独立した別の仕組みなので影響を受けない）。
; dayId が変わったタイミングで自動的にOFFへ戻す（StartWakeRoutine() 内）。
global skipCroquisToday := false

OnToggleSkipCroquis(*) {
    global skipCroquisToday, trayMenu
    skipCroquisToday := !skipCroquisToday
    if (skipCroquisToday)
        trayMenu.Check("🚫 本日のクロッキーをスキップ")
    else
        trayMenu.Uncheck("🚫 本日のクロッキーをスキップ")
    if (skipCroquisToday)
        TrayTip("🚫 クロッキーをスキップ", "本日はクロッキーを実行せず、直接作業を開始します", "Mute")
    else
        TrayTip("✅ スキップ解除", "本日もいつも通りクロッキーを実行します", "Mute")
}

; トレイアイコンのダブルクリックでカウントダウンGUIを最前面に戻す
OnMessage(0x404, OnTrayDblClick)
OnTrayDblClick(wParam, lParam, msg, hwnd) {
    if (lParam = 0x203) {   ; WM_LBUTTONDBLCLK
        try {
            cdGui.Opt("+AlwaysOnTop")
            cdGui.Show("NoActivate")
        }
    }
}

OnNightModeStart(*) {
    global nightModeActive, nightModeEndTick, nightBlockDelay
    if nightModeActive {
        MsgBox("就寝モードはすでに起動中です。")
        return
    }
    nightModeActive  := true
    nightModeEndTick := A_TickCount + (nightBlockDelay * 60 * 1000)
    A_IconTip        := "就寝モード：スマホブロックまで " nightBlockDelay " 分"
    TrayTip("🌙 就寝モード開始", nightBlockDelay " 分後にスマホをブロックします", "Mute")
    SetTimer(NightModeCountdown, 1000)
    ; 3秒後にモニターの電源をオフにする（GPUへの影響なし・マウス操作で復帰）
    SetTimer(TurnOffMonitors, -10000)   ; 通知が消えてから10秒後に消灯
}

TurnOffMonitors() {
    SendMessage(0x0112, 0xF170, 2, , "Program Manager")
}

OnNightModeCancel(*) {
    global nightModeActive
    if !nightModeActive {
        MsgBox("就寝モードは起動していません。")
        return
    }
    nightModeActive := false
    SetTimer(NightModeCountdown, 0)
    A_IconTip := "Work Launcher - 待機中"
    TrayTip("就寝モードキャンセル", "スマホブロックをキャンセルしました", "Mute")
}

NightModeCountdown() {
    global nightModeActive, nightModeEndTick
    if !nightModeActive {
        SetTimer(NightModeCountdown, 0)
        return
    }
    remaining := nightModeEndTick - A_TickCount
    if remaining <= 0 {
        SetTimer(NightModeCountdown, 0)
        nightModeActive := false
        A_IconTip := "Work Launcher - 待機中"
        ; スマホブロックを実行
        NightBlock()
        return
    }
    mins := Ceil(remaining / 60000)
    A_IconTip := "就寝モード：スマホブロックまで " mins " 分"
}

NightBlock() {
    global nextdnsApiKey, nextdnsProfile, nightBlockFlagPath
    global nextdnsCategories, nextdnsServices, nextdnsBlockList

    psPath := A_Temp "\ndns_night_block_now.ps1"
    try FileDelete(psPath)

    q  := Chr(34)
    ps := "$headers = @{ " q "X-Api-Key" q " = " q nextdnsApiKey q " }" . "`n"
    for cat in nextdnsCategories {
        body := "{" q "id" q ":" q cat q "," q "active" q ":true}"
        ps .= "$body = '" body "'; try { Invoke-WebRequest -Uri " q "https://api.nextdns.io/profiles/" nextdnsProfile "/parentalcontrol/categories" q " -Method POST -Headers $headers -Body $body -ContentType " q "application/json" q " -UseBasicParsing | Out-Null } catch { }`n"
    }
    for svc in nextdnsServices {
        body := "{" q "id" q ":" q svc q "," q "active" q ":true}"
        ps .= "$body = '" body "'; try { Invoke-WebRequest -Uri " q "https://api.nextdns.io/profiles/" nextdnsProfile "/parentalcontrol/services" q " -Method POST -Headers $headers -Body $body -ContentType " q "application/json" q " -UseBasicParsing | Out-Null } catch { }`n"
    }
    for domain in nextdnsBlockList {
        body := "{" q "id" q ":" q domain q "," q "active" q ":true}"
        ps .= "$body = '" body "'; try { Invoke-WebRequest -Uri " q "https://api.nextdns.io/profiles/" nextdnsProfile "/denylist" q " -Method POST -Headers $headers -Body $body -ContentType " q "application/json" q " -UseBasicParsing | Out-Null } catch { }`n"
    }
    ps .= "New-Item -Path " q nightBlockFlagPath q " -ItemType File -Force | Out-Null`n"

    FileAppend(ps, psPath, "UTF-8-RAW")
    Run('powershell -WindowStyle Hidden -ExecutionPolicy Bypass -File "' psPath '"', , "Hide")
    ; API呼び出しが完了するまで少し待ってからスリープ
    ; （通知は出さない：モニターが復帰してしまうため）
    SetTimer(SleepPC, -8000)
}

SleepPC() {
    DllCall("PowrProf\SetSuspendState", "Int", 0, "Int", 1, "Int", 0)
}

OnMessage(WM_POWERBROADCAST, OnPower)
countdownEnd  := 0
showAttempts  := 0
countdownMode := ""   ; "croquis" or "main"
wakeRoutineActive := false   ; 待機→クロッキー→作業のルーティンが進行中か（手動実行との二重起動防止用）

OnPower(wParam, lParam, msg, hwnd) {
    global countdownEnd, showAttempts, sleepLogPath, minSleepHours, delayMinutes, skipWDays, wakeRoutineActive

    ; スリープ開始時刻を保存
    ; ただし直前の記録から30分未満の場合は上書きしない（短時間スリープ対策）
    if (wParam = PBT_APMSUSPEND) {
        A_IconTip := "Work Launcher - 待機中"
        shouldWrite := true
        try {
            lastSleep := Trim(FileRead(sleepLogPath))
            minutesSinceLastSleep := DateDiff(A_Now, lastSleep, "Minutes")
            if (minutesSinceLastSleep < 30)
                shouldWrite := false
        }
        if (shouldWrite) {
            try FileDelete(sleepLogPath)
            FileAppend(A_Now, sleepLogPath)
        }

        ; 就寝ブロックは手動トリガー（トレイメニュー→就寝モード開始）方式のみ。
        ; スリープ時刻に基づく自動スケジュールは行わない。
        return
    }

    if (wParam = PBT_APMRESUMEAUTOMATIC) {
        if (wakeRoutineActive)   ; 既にルーティン進行中なら何もしない（多重発火対策）
            return

        ; スキップ曜日チェック
        for wday in skipWDays {
            if (A_WDay = wday)
                return
        }

        ; スリープ時間が閾値未満なら起動しない
        sleepHours := 0
        try {
            sleepStart := Trim(FileRead(sleepLogPath))
            sleepHours := DateDiff(A_Now, sleepStart, "Hours")
        }
        if (sleepHours < minSleepHours)
            return

        StartWakeRoutine()
    }
}

; ===== 待機→クロッキー→作業のルーティンを開始（自動起床・手動実行の共通処理）=====
; isManual: 手動実行（OnManualWakeRoutine）からの呼び出しなら true。
;   自動起床・長時間無操作復帰は、どちらも呼び出し前に「minSleepHours以上の
;   実際の睡眠・無操作」を確認済みなので、常にdayIdを進めて問題ない。
;   一方、手動実行だけはその確認をしない（PC再起動後にすぐ手動実行する、
;   といった使い方を想定しているため）ので、まだ本日のノルマが未達成の
;   状態でdayIdを進めてしまうと、作業途中の1日を誤って「前日」扱いして
;   繰り越し計算にかけてしまい、実効ノルマ・進捗が失われる不具合があった。
StartWakeRoutine(isManual := false) {
    global countdownEnd, countdownMode, showAttempts, delayMinutes, wakeRoutineActive, nightBlockFlagPath
    global currentDayId, dayStatePath, workGoalLogPath, skipCroquisToday, trayMenu

    ; 睡眠明け＝新しい1日の開始とみなし、日付境界（dayId）を1つ進める。
    ; 作業ノルマ・残業時間の判定はカレンダー日付ではなくこの値を基準にする。
    ; ただし手動実行時は、本日分がまだノルマ未達成なら進めない（続きとして扱う）
    shouldAdvanceDay := true
    if (isManual) {
        try {
            _wg := StrSplit(SafeReadFile(workGoalLogPath), "|")
            if (Integer(_wg[1]) = currentDayId && _wg.Length >= 3 && _wg[3] != "1")
                shouldAdvanceDay := false
        }
    }

    if (shouldAdvanceDay) {
        currentDayId += 1
        SafeWriteFile(dayStatePath, currentDayId)

        ; 新しい日になったので「本日のクロッキーをスキップ」設定を自動的にOFFへ戻す
        if (skipCroquisToday) {
            skipCroquisToday := false
            trayMenu.Uncheck("🚫 本日のクロッキーをスキップ")
        }
    } else {
        TrayTip("📅 本日の続き", "本日のノルマがまだ未達成のため、日付を進めずに続行します", "Mute")
    }

    ; 就寝ブロックが実行されていれば起床時に解除
    if FileExist(nightBlockFlagPath) {
        try FileDelete(nightBlockFlagPath)
        Run('schtasks /delete /tn "NightBlock" /f', , "Hide")
        NightUnblock()
    }

    wakeRoutineActive := true

    ; カウントダウン開始（まず通常待機、その後クロッキー）
    countdownEnd  := A_TickCount + (delayMinutes * 60 * 1000)
    countdownMode := "main"
    showAttempts  := 0
    SetTimer(UpdateCountdown, 1000)

    ; GUI表示：5秒・15秒・30秒の3段階でリトライ
    SetTimer(TryShowGui, -5000)
}

; ===== トレイメニュー：スリープ解除ルーティンの手動実行 =====
; バグや寝落ちでスリープが検知されなかった場合などに、
; 待機→（食事休憩を挟んで）クロッキー→作業 の流れを手動で開始します。
; 自動起床時と異なり、曜日スキップ・最短スリープ時間のチェックは行いません。
OnManualWakeRoutine(*) {
    global wakeRoutineActive, phaseFile, delayMinutes

    if (wakeRoutineActive) {
        TrayTip("⚠️ 実行できません", "スリープ解除ルーティンは既に進行中です", "Mute")
        return
    }

    phaseNow := ""
    try phaseNow := Trim(SafeReadFile(phaseFile))
    if (phaseNow != "") {
        TrayTip("⚠️ 実行できません", "作業タイマーが既に起動中のようです", "Mute")
        return
    }

    TrayTip("🔁 スリープ解除ルーティン", delayMinutes "分待機 → クロッキー → 作業 を開始します", "Mute")
    StartWakeRoutine(true)
}

; ===== 右脳ドローイング：テスト実行（トレイメニュー専用・変更不要）=====
;
;    croquisModeParams には登録していない、テスト専用の入口。
;    起床ルーティン（待機・カウントダウン）は挟まず、その場で直接
;    lock_window.ahk をモード6・テストフラグ付きで起動する。
;    テスト実行では croquis_used_fast.txt への書き込み（使用済みマーク）を
;    行わないため、何度実行しても画像プールは消費されない。
;
;    【要望】実行中はメニュー項目が「🧪 テストモードを終了」に変わり、
;    押すと fast_croquis_stop.txt を作成してlock_window.ahk側へ手動停止を
;    知らせる（lock_window.ahk側の各ティック関数がこのファイルを検知して
;    参照ウィンドウを閉じ正常終了する）。終了を検知したら自動的に
;    メニュー項目を元の文言に戻す。
global fastCroquisTestRunning    := false
global fastCroquisTestSeenActive := false
fastCroquisStopFlagPath := A_ScriptDir "\fast_croquis_stop.txt"

OnFastCroquisTest(*) {
    global scriptPath, phaseFile, trayMenu, fastCroquisTestRunning, fastCroquisTestSeenActive, fastCroquisStopFlagPath

    if (fastCroquisTestRunning) {
        ; 実行中に押された＝手動停止シグナルを送る（グレースフルシャットダウン）
        SafeWriteFile(fastCroquisStopFlagPath, "1")
        TrayTip("🧪 テストモード", "終了処理中です…", "Mute")
        return
    }

    phaseNow := ""
    try phaseNow := Trim(SafeReadFile(phaseFile))
    if (phaseNow != "") {
        TrayTip("⚠️ 実行できません", "作業タイマーが既に起動中のようです", "Mute")
        return
    }

    SafeDeleteFile(fastCroquisStopFlagPath)   ; 前回分の停止シグナルが残っていないようにする

    TrayTip("🧪 右脳ドローイング（テスト）", "60秒 × 25セットのテストを開始します", "Mute")
    ; /croquis:lockSecs:sets:interSecs:mode:test
    ;   60秒 × 25セット、開始前の待機180秒（参照ウィンドウの位置調整用）、
    ;   モード6、テストフラグ=1
    Run('"' scriptPath '" /croquis:60:25:180:6:1')

    fastCroquisTestRunning    := true
    fastCroquisTestSeenActive := false
    trayMenu.Rename("🧪 右脳ドローイング（テスト実行）", "🧪 テストモードを終了")
    SetTimer(WaitForFastCroquisTestEnd, 2000)
}

; テスト実行の終了を監視し、メニュー項目の文言を自動で元に戻す（変更不要）
WaitForFastCroquisTestEnd() {
    global phaseFile, trayMenu, fastCroquisTestRunning, fastCroquisTestSeenActive

    phaseNow := ""
    try phaseNow := Trim(SafeReadFile(phaseFile))

    ; 起動直後はまだファイルが更新されておらず一瞬 "" のことがあるため、
    ; 一度でも中身がある状態を確認してから「空に戻った＝終了」と判定する
    if (phaseNow != "")
        fastCroquisTestSeenActive := true

    if (fastCroquisTestSeenActive && phaseNow = "") {
        SetTimer(WaitForFastCroquisTestEnd, 0)
        fastCroquisTestRunning := false
        trayMenu.Rename("🧪 テストモードを終了", "🧪 右脳ドローイング（テスト実行）")
        TrayTip("🧪 テストモード", "終了しました", "Mute")
    }
}

; ===== 無操作時間ベースの起床検知（変更不要）=====
; 画面がオフになるだけでPC自体はスリープしない設定の場合、そのまま寝落ちしても
; PBT_APMRESUMEAUTOMATIC（実際のスリープ復帰）が一切発生せず、
; ルーティンが永遠に始まらないことがある。これを補うため、
; 「minSleepHours 以上無操作が続いた後、操作が再開された瞬間」を
; 実際のスリープ復帰と同じ意味とみなし、同じルーティンを起動する。
longIdleDetected := false
SetTimer(CheckLongIdleWake, 60000)   ; 1分ごとに監視

CheckLongIdleWake() {
    global longIdleDetected, minSleepHours, wakeRoutineActive, skipWDays, phaseFile

    idleMs      := A_TimeIdlePhysical
    thresholdMs := minSleepHours * 60 * 60 * 1000

    if (idleMs >= thresholdMs) {
        ; まだ無操作が続いている＝本人はまだ戻ってきていないので何もしない
        longIdleDetected := true
        return
    }

    if (!longIdleDetected)
        return   ; 直近に長時間無操作が無かった（通常の利用中）

    ; ここに来るのは「長時間無操作の後、操作を検知した」瞬間
    longIdleDetected := false

    if (wakeRoutineActive)
        return   ; 既にルーティン進行中（実際のスリープ復帰等）なら何もしない

    ; lock_window.ahk が既に動作中なら何もしない
    phaseNow := ""
    try phaseNow := Trim(SafeReadFile(phaseFile))
    if (phaseNow != "")
        return

    ; スキップ曜日チェック（実際のスリープ復帰と同じ判定）
    for wday in skipWDays {
        if (A_WDay = wday)
            return
    }

    StartWakeRoutine()
}

; ===== GUI表示リトライ（変更不要）=====
TryShowGui() {
    global showAttempts, countdownEnd
    if (countdownEnd <= A_TickCount)
        return   ; すでにカウントダウン終了していたら何もしない
    showAttempts += 1
    ; 初回のみ前日サボりログを表示
    if (showAttempts = 1)
        ShowSaboLog()
    cdGui.Show("Center w240 h120 NoActivate")
    if (showAttempts = 1)
        SetTimer(TryShowGui, -10000)
    else if (showAttempts = 2)
        SetTimer(TryShowGui, -15000)
}

; ===== カウントダウン更新（変更不要）=====
; トレイアイコンのツールチップにも残り時間を表示します。
; タスクバーのランチャーアイコンにマウスを乗せると確認できます。
UpdateCountdown() {
    global countdownEnd, countdownMode
    remaining := countdownEnd - A_TickCount

    if (remaining <= 0) {
        SetTimer(UpdateCountdown, 0)
        SetTimer(TryShowGui, 0)
        cdGui.Hide()
        A_IconTip := "Work Launcher - 待機中"
        if (countdownMode = "main") {
            ; 食事時間内ならクロッキーを食事休憩終了まで延期
            if (IsMealTime()) {
                WaitForMealEnd()
            } else {
                LaunchCroquis()
            }
        } else if (countdownMode = "croquis") {
            LaunchMain()
        } else {
            LaunchCroquis()
        }
        return
    }

    secs := Ceil(remaining / 1000)
    mins := secs // 60
    secs := Mod(secs, 60)
    timeStr := Format("{:02d}:{:02d}", mins, secs)

    ; トレイアイコンのツールチップを更新（常に確実に表示される）
    label := (countdownMode = "croquis") ? "クロッキー開始まで " : "作業開始まで "
    A_IconTip := label timeStr

    ; GUIのカウントも更新
    try cdCount.Value := timeStr
}

; ===== 毎日23時にログファイルを書き出す（変更不要）=====
; 書き出し後、翌日の23時に再スケジュールします。
ScheduleDailyLog() {
    now      := A_Now
    target   := FormatTime(now, "yyyyMMdd") "230000"   ; 今日の23:00:00（DateDiff用にダッシュなし形式）
    msUntil  := DateDiff(target, now, "Seconds") * 1000
    if (msUntil <= 0)
        msUntil := msUntil + 86400000   ; すでに23時を過ぎていたら翌日
    SetTimer(WriteDailyLog, -msUntil)
}

WriteDailyLog() {
    global sabo, saboLogDir

    today   := FormatTime(, "yyyy-MM-dd")
    logPath := saboLogDir "\" today "_sabo.txt"

    ; ファイルを新規作成（上書き）
    try FileDelete(logPath)

    if (sabo.entries.Length = 0) {
        FileAppend("サボり検知なし`n", logPath)
    } else {
        for entry in sabo.entries
            FileAppend(entry "`n", logPath)
    }

    ; 翌日の23時に再スケジュール
    SetTimer(WriteDailyLog, -86400000)
}

; 起動時に23時タイマーをセット
ScheduleDailyLog()

; 起動時にクロッキー週次レポートタイマーをセット
ScheduleCroquisReport()

; ===== テスト用：週次レポートを今すぐ送信して動作確認する =====
; 使い方: launcher.ahk /test-croquis-report
; ※ #SingleInstance Force のため、実行中のlauncher.ahkはこの起動によって
;   一度終了し、この新しいプロセスに置き換わります（通常の起動処理はそのまま続行されます）。
;   本番のDiscordチャンネルに実際に送信されるので注意してください。
if (A_Args.Length > 0 && A_Args[1] = "/test-croquis-report") {
    TrayTip("🧪 テスト送信", "クロッキー週次レポートを今すぐ送信します…", "Mute")
    SendCroquisWeeklyReport(true)
}

; ===== クロッキー週次レポート：スケジュール（変更不要）=====
ScheduleCroquisReport() {
    global croquisReportWDay, croquisReportHour

    ; 今週の「送信曜日」が何日後かを計算
    ; A_WDay: 1=日 ～ 7=土
    now        := A_Now
    todayWDay  := A_WDay
    todayH     := Integer(FormatTime(, "H"))
    todayM     := Integer(FormatTime(, "m"))

    ; 次の送信タイミングまでの日数を求める
    daysUntil := Mod(croquisReportWDay - todayWDay + 7, 7)
    ; 今日が送信曜日かつまだ送信時刻前なら今日送る、過ぎていれば7日後
    if (daysUntil = 0) {
        if (todayH > croquisReportHour || (todayH = croquisReportHour && todayM > 0))
            daysUntil := 7   ; 今日の時刻を過ぎていたら来週
    }

    targetDate   := FormatTime(DateAdd(now, daysUntil, "Days"), "yyyyMMdd")
    targetDT     := targetDate Format("{:02d}0000", croquisReportHour)
    msUntil      := DateDiff(targetDT, now, "Seconds") * 1000
    if (msUntil < 0)
        msUntil := 0

    SetTimer(SendCroquisWeeklyReport, -msUntil)
}

; ===== クロッキー週次レポート送信（変更不要）=====
; isTest=true の場合、送信結果ログをMsgBoxで表示する（動作確認用）
SendCroquisWeeklyReport(isTest := false) {
    global croquisShotDir, croquisReportWebhook

    resultLogPath := A_ScriptDir "\croquis_report_log.txt"
    try FileDelete(resultLogPath)

    if (croquisReportWebhook = "") {
        FileAppend(FormatTime(, "HH:mm:ss") " croquisReportWebhookが未設定のため送信をスキップしました`n", resultLogPath)
        if (isTest)
            MsgBox("croquisReportWebhook が空のため送信できません。`n設定を確認してください。", "クロッキー週次レポート テスト結果")
        if (!isTest)
            ScheduleCroquisReport()   ; 次週へ
        return
    }

    ; 過去7日分の画像を収集
    shots := []
    loop files croquisShotDir "\*.png" {
        ; ファイル名から日付を取得（yyyy-MM-dd_HH-mm.png）
        fname := A_LoopFileName
        try {
            dateStr := SubStr(fname, 1, 10)                    ; "yyyy-MM-dd"
            fileDate := StrReplace(dateStr, "-", "")           ; "yyyyMMdd"
            weekAgo  := FormatTime(DateAdd(A_Now, -7, "Days"), "yyyyMMdd")
            if (fileDate >= weekAgo)
                shots.Push(A_LoopFileFullPath)
        }
    }

    ; 枚数・日付一覧テキストを作成
    count   := shots.Length
    dateSet := Map()
    for path in shots {
        fname   := SubStr(path, InStr(path, "\",, -1) + 1)
        dateStr := SubStr(fname, 1, 10)
        dateSet[dateStr] := true
    }
    dateList := []
    for d, _ in dateSet
        dateList.Push(d)

    ; 日付を昇順ソート（StrCompareで明示的に文字列比較する）
    ; ※ "-" 区切りの日付文字列同士を ">" で直接比較すると、AHKv2側の解釈次第で
    ;   "Expected a Number but got a String" エラーになることがあるため注意
    n := dateList.Length
    loop n - 1 {
        i := A_Index
        loop n - i {
            j := A_Index + i
            if (StrCompare(dateList[j-1], dateList[j]) > 0) {
                tmp          := dateList[j-1]
                dateList[j-1] := dateList[j]
                dateList[j]   := tmp
            }
        }
    }

    dateText := ""
    for d in dateList
        dateText .= d " / "
    dateText := RTrim(dateText, " / ")

    weekStart := FormatTime(DateAdd(A_Now, -6, "Days"), "yyyy/MM/dd")
    weekEnd   := FormatTime(A_Now, "yyyy/MM/dd")
    msgText   := "🎨 **クロッキー週次レポート** (" weekStart " ～ " weekEnd ")`n"
                . "今週の枚数：**" count " 枚**`n"
                . (dateText != "" ? "実施日：" dateText : "今週は0枚でした")
                . (isTest ? "`n（テスト送信）" : "")

    FileAppend(FormatTime(, "HH:mm:ss") " 対象画像 " count " 枚を検出（" dateText "）`n", resultLogPath)

    if (count = 0) {
        ; 画像なしの場合はテキストのみ送信
        SendDiscordAlert(msgText)
        FileAppend(FormatTime(, "HH:mm:ss") " 画像0枚のためテキストのみ送信しました`n", resultLogPath)
        if (isTest)
            MsgBox(FileRead(resultLogPath), "クロッキー週次レポート テスト結果")
        if (!isTest)
            ScheduleCroquisReport()
        return
    }

    ; PowerShellで画像をmultipart送信
    q  := Chr(34)
    ps := "Add-Type -AssemblyName System.Net.Http`n"
    ps .= "$logPath = " q resultLogPath q "`n"
    ps .= "function Log(`$msg) { Add-Content -Path `$logPath -Value ((Get-Date -Format " q "HH:mm:ss" q ") + ' ' + `$msg) }`n"
    ps .= "Log('PowerShell側の送信処理を開始')`n"
    ps .= "$url    = " q croquisReportWebhook q "`n"
    ps .= "$client = [System.Net.Http.HttpClient]::new()`n"
    ps .= "$form   = [System.Net.Http.MultipartFormDataContent]::new()`n"

    ; テキスト部分（Content-Type を明示）
    ; PowerShell側の ConvertTo-Json に任せて安全にJSON化する。
    ; （手動で {"content":"..."} を組み立てると、JSON用の " とPowerShell文字列の
    ;   " が衝突してスクリプト自体がパースエラーになり、何も送信されず
    ;   ログにも何も残らないという状態になっていた）
    psSafeMsg := StrReplace(msgText, "'", "''")   ; PowerShellのシングルクォート内エスケープ
    ps .= "$msgText  = '" psSafeMsg "'`n"
    ps .= "$jsonBody = (@{ content = $msgText } | ConvertTo-Json -Compress)`n"
    ps .= "$payload = [System.Net.Http.StringContent]::new(`$jsonBody, [System.Text.Encoding]::UTF8, " q "application/json" q ")`n"
    ps .= "$payload.Headers.ContentType = [System.Net.Http.Headers.MediaTypeHeaderValue]::Parse(" q "application/json" q ")`n"
    ps .= "$form.Add(`$payload, " q "payload_json" q ")`n"

    ; 画像ファイルを添付（最大10枚。超える場合は新しい順に切る）
    attachShots := shots
    if (attachShots.Length > 10) {
        trimmed := []
        startIdx := attachShots.Length - 9
        loop 10 {
            trimmed.Push(attachShots[startIdx + A_Index - 1])
        }
        attachShots := trimmed
    }

    for i, path in attachShots {
        fname := SubStr(path, InStr(path, "\",, -1) + 1)
        ps .= "try {`n"
        ps .= "    $bytes" i " = [System.IO.File]::ReadAllBytes(" q path q ")`n"
        ps .= "    $mem"   i " = [System.Net.Http.ByteArrayContent]::new(`$bytes" i ")`n"
        ps .= "    $mem"   i ".Headers.ContentType = [System.Net.Http.Headers.MediaTypeHeaderValue]::Parse(" q "image/png" q ")`n"
        ps .= "    $form.Add(`$mem" i ", " q "files[" (i-1) "]" q ", " q fname q ")`n"
        ps .= "    Log('画像読込OK: " fname "')`n"
        ps .= "} catch {`n"
        ps .= "    Log('画像読込失敗: " fname " - ' + `$_.Exception.Message)`n"
        ps .= "}`n"
    }

    ps .= "try {`n"
    ps .= "    $resp = $client.PostAsync(`$url, `$form).Result`n"
    ps .= "    if ($resp.IsSuccessStatusCode) {`n"
    ps .= "        Log('送信成功: HTTP ' + [int]$resp.StatusCode)`n"
    ps .= "    } else {`n"
    ps .= "        $body = $resp.Content.ReadAsStringAsync().Result`n"
    ps .= "        Log('送信失敗: HTTP ' + [int]$resp.StatusCode + ' ' + $resp.ReasonPhrase + ' / レスポンス: ' + $body)`n"
    ps .= "    }`n"
    ps .= "} catch {`n"
    ps .= "    Log('例外発生: ' + $_.Exception.Message)`n"
    ps .= "}`n"
    ps .= "$client.Dispose()`n"
    ps .= "Log('PowerShell側の送信処理が終了')`n"

    psPath := A_Temp "\croquis_weekly.ps1"
    try FileDelete(psPath)
    ; BOMなしのUTF-8だと、Windows PowerShell(5.1)がスクリプト内の日本語部分を
    ; システムのANSIコードページとして誤読し、文字列が壊れてパースエラーになることがある。
    ; BOM付きUTF-8で書き出すことでUTF-8として確実に認識させる。
    FileAppend(ps, psPath, "UTF-8")
    ; RunWait で完了を待ってからTrayTipを表示
    RunWait('powershell -WindowStyle Hidden -ExecutionPolicy Bypass -File "' psPath '"',, "Hide")

    TrayTip("🎨 週次レポート送信", count " 枚を送信処理しました（詳細: " resultLogPath "）", "Mute")

    if (isTest) {
        logContent := ""
        try logContent := FileRead(resultLogPath)
        MsgBox(logContent, "クロッキー週次レポート テスト結果")
    }

    ; 次週へ再スケジュール（テスト時は本来のスケジュールを崩さない）
    if (!isTest)
        ScheduleCroquisReport()
}

; ===== 就寝ブロック：起床時解除（変更不要）=====
NightUnblock() {
    global nextdnsApiKey, nextdnsProfile
    global nextdnsCategories, nextdnsServices, nextdnsBlockList

    psPath := A_Temp "\ndns_night_unblock.ps1"
    try FileDelete(psPath)

    q  := Chr(34)
    ps := "$headers = @{ " q "X-Api-Key" q " = " q nextdnsApiKey q " }" . "`n"

    for cat in nextdnsCategories {
        ps .= "try { Invoke-WebRequest -Uri " q "https://api.nextdns.io/profiles/" nextdnsProfile "/parentalcontrol/categories/" cat q " -Method DELETE -Headers $headers -UseBasicParsing | Out-Null } catch { }`n"
    }
    for svc in nextdnsServices {
        ps .= "try { Invoke-WebRequest -Uri " q "https://api.nextdns.io/profiles/" nextdnsProfile "/parentalcontrol/services/" svc q " -Method DELETE -Headers $headers -UseBasicParsing | Out-Null } catch { }`n"
    }
    for domain in nextdnsBlockList {
        ps .= "try { Invoke-WebRequest -Uri " q "https://api.nextdns.io/profiles/" nextdnsProfile "/denylist/" domain q " -Method DELETE -Headers $headers -UseBasicParsing | Out-Null } catch { }`n"
    }

    FileAppend(ps, psPath, "UTF-8-RAW")
    Run('powershell -WindowStyle Hidden -ExecutionPolicy Bypass -File "' psPath '"', , "Hide")
    TrayTip("📶 スマホブロック解除", "起床を検知しました。NextDNS のブロックを解除します", "Mute")
}

SkipCountdown() {
    global countdownEnd
    countdownEnd := A_TickCount   ; 残り時間をゼロにして次のTickで即発火させる
}

; ===== 食事時間判定（変更不要）=====
IsMealTime() {
    global mealPauseStartH, mealPauseStartM, mealPauseEndH, mealPauseEndM
    nowMin   := Integer(FormatTime(, "H")) * 60 + Integer(FormatTime(, "m"))
    startMin := mealPauseStartH * 60 + mealPauseStartM
    endMin   := mealPauseEndH   * 60 + mealPauseEndM
    return (nowMin >= startMin && nowMin < endMin)
}

; ===== 食事休憩終了まで待機してからクロッキー起動（変更不要）=====
WaitForMealEnd() {
    global mealPauseEndH, mealPauseEndM
    endStr := Format("{:02d}:{:02d}", mealPauseEndH, mealPauseEndM)
    TrayTip("🍽️ 食事休憩中", "クロッキーは " endStr " に開始します", "Mute")
    try {
        cdLabel.Value := "食事休憩中..."
        cdGui.Show("Center w240 h120 NoActivate")
    }
    SetTimer(CheckMealEndForCroquis, 30000)
}

CheckMealEndForCroquis() {
    if (!IsMealTime()) {
        SetTimer(CheckMealEndForCroquis, 0)
        cdGui.Hide()
        TrayTip("🎨 クロッキー開始", "食事休憩が終わりました", "Mute")
        LaunchCroquis()
    }
}

; ===== クリップボードへの画像コピー（変更不要）=====
CopyImageToClipboard(path) {
    hGdiPlus := DllCall("LoadLibrary", "Str", "gdiplus.dll", "Ptr")
    if (!hGdiPlus)
        return

    token := 0
    si    := Buffer(24, 0)
    NumPut("UInt", 1, si, 0)
    DllCall("gdiplus\GdiplusStartup", "Ptr*", &token, "Ptr", si, "Ptr", 0)

    pBitmap := 0
    r := DllCall("gdiplus\GdipCreateBitmapFromFile", "WStr", path, "Ptr*", &pBitmap)
    if (r != 0 || !pBitmap) {
        DllCall("gdiplus\GdiplusShutdown", "Ptr", token)
        return
    }

    width := 0, height := 0
    DllCall("gdiplus\GdipGetImageWidth",  "Ptr", pBitmap, "UInt*", &width)
    DllCall("gdiplus\GdipGetImageHeight", "Ptr", pBitmap, "UInt*", &height)

    stride  := width * 4
    dibSize := 40 + (stride * height)
    hDib    := DllCall("GlobalAlloc", "UInt", 2, "UPtr", dibSize, "Ptr")
    pDib    := DllCall("GlobalLock", "Ptr", hDib, "Ptr")

    NumPut("UInt",   40,              pDib,  0)
    NumPut("Int",    width,           pDib,  4)
    NumPut("Int",    -height,         pDib,  8)
    NumPut("UShort", 1,               pDib, 12)
    NumPut("UShort", 32,              pDib, 14)
    NumPut("UInt",   0,               pDib, 16)
    NumPut("UInt",   stride * height, pDib, 20)
    loop 5
        NumPut("UInt", 0, pDib, 24 + (A_Index - 1) * 4)

    rect := Buffer(16, 0)
    NumPut("Int", 0,      rect,  0)
    NumPut("Int", 0,      rect,  4)
    NumPut("Int", width,  rect,  8)
    NumPut("Int", height, rect, 12)

    bmpData := Buffer(32, 0)
    NumPut("UInt", stride,     bmpData,  8)
    NumPut("UInt", 0x0026200A, bmpData, 12)
    NumPut("Ptr",  pDib + 40,  bmpData, 16)

    DllCall("gdiplus\GdipBitmapLockBits",
        "Ptr", pBitmap, "Ptr", rect,
        "UInt", 5, "Int", 0x0026200A, "Ptr", bmpData)
    DllCall("gdiplus\GdipBitmapUnlockBits", "Ptr", pBitmap, "Ptr", bmpData)
    DllCall("gdiplus\GdipDisposeImage", "Ptr", pBitmap)
    DllCall("gdiplus\GdiplusShutdown", "Ptr", token)
    DllCall("GlobalUnlock", "Ptr", hDib)

    hBitmap := 0
    hdc     := DllCall("GetDC", "Ptr", 0, "Ptr")
    hBitmap := DllCall("CreateDIBitmap", "Ptr", hdc,
        "Ptr", pDib, "UInt", 4, "Ptr", pDib + 40, "Ptr", pDib, "UInt", 0, "Ptr")
    DllCall("ReleaseDC", "Ptr", 0, "Ptr", hdc)

    DllCall("OpenClipboard", "Ptr", 0)
    DllCall("EmptyClipboard")
    if (hBitmap)
        DllCall("SetClipboardData", "UInt", 2, "Ptr", hBitmap)
    DllCall("SetClipboardData",     "UInt", 8, "Ptr", hDib)
    DllCall("CloseClipboard")
}

; ===== クロッキー：画像選択（変更不要）=====
; 指定フォルダからランダムに1枚選ぶ。全周済みならリセットして再選択。
; mode番号を受け取り、そのモード専用フォルダ・使用済みログを使う
PickCroquisImage(mode) {
    global croquisModeParams, croquisUsedLog

    folder := croquisModeParams.Has(mode) ? croquisModeParams[mode].folder : croquisModeParams[1].folder

    ; 対象拡張子
    exts := ["*.jpg", "*.jpeg", "*.png", "*.bmp", "*.webp"]

    ; フォルダ内の全画像を列挙
    allImages := []
    for ext in exts {
        loop files folder "\" ext {
            allImages.Push(A_LoopFileName)
        }
    }

    if (allImages.Length = 0)
        return ""   ; 画像なし

    ; 使用済みリストを読み込む（モードをまたいで一元管理。同じ画像がどのモードでも
    ; 二度使われないようにするため、croquisUsedLog は全モード共通の1ファイル）
    usedList := []
    try {
        raw := FileRead(croquisUsedLog)
        loop parse raw, "`n", "`r" {
            if (Trim(A_LoopField) != "")
                usedList.Push(Trim(A_LoopField))
        }
    }

    ; 未使用画像を抽出
    unused := []
    for img in allImages {
        alreadyUsed := false
        for u in usedList {
            if (StrLower(u) = StrLower(img)) {
                alreadyUsed := true
                break
            }
        }
        if (!alreadyUsed)
            unused.Push(img)
    }

    ; このモードのフォルダを全部使い切ったら、共有リストから
    ; 「このモードの画像分だけ」を取り除いてリセットする
    ; （他モードの使用履歴はそのまま残す＝他モードの画像が誤って再度使えるようになるのを防ぐ）
    if (unused.Length = 0) {
        remaining := []
        for u in usedList {
            belongsToThisMode := false
            for img in allImages {
                if (StrLower(u) = StrLower(img)) {
                    belongsToThisMode := true
                    break
                }
            }
            if (!belongsToThisMode)
                remaining.Push(u)
        }
        try FileDelete(croquisUsedLog)
        for r in remaining
            FileAppend(r "`n", croquisUsedLog)
        unused := allImages
        TrayTip("🎨 クロッキー", "モード" mode "の画像を全て使い切ったためリセットしました", "Mute")
    }

    ; ランダム選択
    idx      := Random(1, unused.Length)
    selected := unused[idx]

    ; 使用済みに追記
    FileAppend(selected "`n", croquisUsedLog)

    return folder "\" selected
}

; ===== クロッキー起動（変更不要）=====
; ===== 週間スケジュールの確認（変更不要）=====
; mode_scheduler.ahk（別スクリプト）で保存された croquis_schedule.txt を読み、
; 今日の曜日に対応するモードを返す。
; 土曜日はもともと休み（skipWDays）のためスケジュール対象外。ファイルは
; 日〜金の6曜日分のみ保存されている（A_WDay: 1=日〜6=金がそのまま添字に一致）。
; 戻り値: 1〜5 ならそのモードを使う。0 ならスケジュール未設定／その曜日は
; 「ランダム」に設定済み／土曜日／ファイルが無い・壊れている、のいずれか
; （呼び出し側で croquisMode 設定・ランダム抽選にフォールバックする）。
GetScheduledCroquisMode() {
    global croquisSchedulePath

    if (A_WDay = 7)   ; 土曜日は対象外
        return 0

    try {
        raw   := Trim(SafeReadFile(croquisSchedulePath))
        parts := StrSplit(raw, "|")
        if (parts.Length = 6) {
            n := Integer(parts[A_WDay])
            if ((n >= 1 && n <= 5) || n = 7)
                return n
        }
    }
    return 0
}

LaunchCroquis() {
    global scriptPath, croquisMode, croquisModeParams, croquisRandomExcludeModes, croquisModeCyclePath, croquisSchedulePath, delayMinutes, countdownEnd, countdownMode, skipCroquisToday

    ; 【要望】トレイメニューで「本日のクロッキーをスキップ」がONなら、
    ; モード選択等は一切行わず直接作業タイマーを起動する
    if (skipCroquisToday) {
        TrayTip("🚫 クロッキーをスキップ", "作業タイマーを開始します", "Mute")
        LaunchMain()
        return
    }

    ; 【要望】週間スケジュール（mode_scheduler.ahk で保存）に今日の曜日の設定があれば、
    ; croquisMode の設定やランダム抽選より優先してそのモードを使う。
    ; スケジュール側で「ランダム」に設定されている曜日、またはスケジュール自体が
    ; 無い・壊れている場合は 0 が返るので、これまでどおりの分岐にフォールバックする。
    targetMode := croquisMode
    scheduledMode := GetScheduledCroquisMode()
    if (scheduledMode > 0) {
        targetMode := scheduledMode
        TrayTip("📅 スケジュール", "本日はモード" targetMode "です（週間スケジュール設定済み）", "Mute")
    } else if (croquisMode = 0) {
        ; ランダムモード（croquisMode = 0）：既存モードの中から毎回ランダムに1つ選ぶ
        ; ※ croquisMode 自体（設定値）は書き換えない。今回の起動用に一時的に決めるだけ
        ; 全モードを一周するまでは被りなしで選び、一周したらまた全モードから選び直す
        availableModes := []
        for k, v in croquisModeParams {
            excluded := false
            for ex in croquisRandomExcludeModes {
                if (ex = k) {
                    excluded := true
                    break
                }
            }
            if (!excluded)
                availableModes.Push(k)
        }
        if (availableModes.Length = 0) {
            ; 除外しすぎて選べるモードが無い場合は、除外を無視して全モードから選ぶ
            for k, v in croquisModeParams
                availableModes.Push(k)
        }

        ; このサイクルで既に選ばれたモードを読み込む
        usedModes := []
        raw := Trim(SafeReadFile(croquisModeCyclePath))
        if (raw != "") {
            for part in StrSplit(raw, ",") {
                try usedModes.Push(Integer(part))
            }
        }

        ; 候補から「このサイクルでまだ選ばれていないモード」だけを残す
        ; （croquisRandomExcludeModes が前回起動時と変わっていても、単純に
        ;   availableModes と usedModes の差分を取るだけなので自然に整合する）
        remainingModes := []
        for m in availableModes {
            isUsed := false
            for u in usedModes {
                if (u = m) {
                    isUsed := true
                    break
                }
            }
            if (!isUsed)
                remainingModes.Push(m)
        }

        ; 候補が尽きた（1周した）場合は、そこでリセットして全候補から選び直す
        cycleReset := (remainingModes.Length = 0)
        if (cycleReset) {
            remainingModes := availableModes.Clone()
            usedModes := []
        }

        targetMode := remainingModes[Random(1, remainingModes.Length)]
        usedModes.Push(targetMode)

        usedStr := ""
        for i, m in usedModes
            usedStr .= (i = 1 ? "" : ",") m
        SafeWriteFile(croquisModeCyclePath, usedStr)

        cycleNote := cycleReset ? "（新しい周を開始）" : "（残り" (remainingModes.Length - 1) "モード）"
        TrayTip("🎲 ランダムモード", "今回はモード" targetMode "が選ばれました " cycleNote, "Mute")
    }

    ; モードパラメータ取得（未定義なら1にフォールバック）
    params := croquisModeParams.Has(targetMode) ? croquisModeParams[targetMode] : croquisModeParams[1]
    useMode := croquisModeParams.Has(targetMode) ? targetMode : 1

    ; モード5・7（教本の模写。タイマー時間が違うだけで挙動は同じ）は画像を
    ; 一切使わないため、フォルダ確認・画像選択・クリップボードコピーをすべてスキップする
    noImageMode := (useMode = 5 || useMode = 7)

    if (!noImageMode) {
        if (!DirExist(params.folder)) {
            TrayTip("⚠️ クロッキースキップ", "モード" useMode "の画像フォルダが見つかりません：" params.folder, "Mute")
            LaunchMain()
            return
        }

        imgPath := PickCroquisImage(useMode)
        if (imgPath = "") {
            TrayTip("⚠️ クロッキースキップ", "モード" useMode "のフォルダ内に画像が見つかりませんでした", "Mute")
            LaunchMain()
            return
        }

        ; 画像をクリップボードにコピー
        CopyImageToClipboard(imgPath)
        TrayTip("🎨 クロッキー開始", "モデル画像をクリップボードにコピーしました`nクリスタのサブビューに貼り付けてください", "Mute")
    } else {
        TrayTip("📖 クロッキー開始（教本模写）", "教本を開いて準備してください", "Mute")
    }

    ; lock_window.ahk を /croquis モードで起動（パラメータとモード番号を引数で渡す）
    ; モード番号を渡すのは、セット間の次画像選択（lock_window.ahk側）でも
    ; 同じモード専用フォルダから選ぶ必要があるため
    Run('"' scriptPath '" /croquis:' params.lockSecs ':' params.sets ':' params.interSecs ':' useMode)

    ; クロッキー終了を監視（2秒ごとにフェーズファイルを確認）
    SetTimer(WaitForCroquisEnd, 2000)
}

WaitForCroquisEnd() {
    ; lock_window.ahk が終了したか確認（フェーズファイルが空になった）
    phaseNow := ""
    try phaseNow := Trim(SafeReadFile(A_ScriptDir "\current_phase.txt"))

    ; プロセスが存在するか確認
    lockRunning := ProcessExist("AutoHotkey64.exe") || ProcessExist("AutoHotkey.exe")

    ; フェーズが "croquis_done" になったら通常フローへ移行
    if (phaseNow = "croquis_done") {
        SetTimer(WaitForCroquisEnd, 0)
        SafeDeleteFile(A_ScriptDir "\current_phase.txt")
        TrayTip("🎨 クロッキー完了", "作業タイマーを開始します", "Mute")
        LaunchMain()
    }
}

; ===== クロッキー後の通常タイマー起動（変更不要）=====
LaunchMainAfterCroquis() {
    global countdownEnd, countdownMode, delayMinutes

    ; 残り待機時間のカウントダウンを再開
    countdownEnd  := A_TickCount + (delayMinutes * 60 * 1000)
    countdownMode := "main"

    ; GUIラベルを「作業開始まで」に更新して再表示
    try cdLabel.Value := "作業開始まで..."
    try cdGui.Opt("+AlwaysOnTop")
    cdGui.Show("Center w240 h120 NoActivate")
    SetTimer(UpdateCountdown, 1000)
    A_IconTip := "作業開始まで " delayMinutes " 分"
}

LaunchMain() {
    global scriptPath, wakeRoutineActive
    wakeRoutineActive := false   ; 待機→クロッキー→作業のルーティンはここで完了
    Run('"' scriptPath '" /auto')
}

; ================================================================
; ★ サボり検知の設定
;
;    absentThresholdMin
;      → 何分間操作がなければ「サボり離席」とみなすか。
;        食事・トイレ等を考慮して長めに設定することを推奨します。
;        警告通知はこの1分前（threshold-1分）に出ます。
; ================================================================
absentThresholdMin := 15

; ================================================================
; ★ Discord 通知設定（lock_window.ahk と同じURLを設定してください）
; ================================================================
discordWebhook := "https://discord.com/api/webhooks/1514960540949282948/QWx9sLWEDVBct8MUXU5EvsgiGKcY5C3BRriVil5Ye_yM2hvCKJPfFdI-MryZNVmhDXBS?thread_id=1514960461815353394"

; ================================================================
; ★ サボり警告の送信先（もうすぐサボり判定になります通知）
;    discordWebhook とは別のサーバーに送りたい場合はここに設定
; ================================================================
saboWarnWebhook := "https://discord.com/api/webhooks/1518930448896491520/Qg_f0kW5O-oj7Wysy5jn-VKax75jRV9cOpbIIPT7V1nOCgUE6Th4zWx3mRWR5UGN5_A5"   ; ← 警告専用の Webhook URL を入力してください

; ===== サボりログのパス（変更不要）=====
; 日付ごとに1ファイル作成されます。翌朝スリープ解除時に内容が表示されます。
; 手動でDiscordに貼り付けてください。
saboLogDir  := A_ScriptDir "\sabo_logs"
phaseFile   := A_ScriptDir "\current_phase.txt"
sentinelPath := A_ScriptDir "\launcher_running.txt"

; ===== サボり検知の内部状態（変更不要）=====
global sabo := {
    isAbsent:       false,
    absentStartMs:  0,
    saboCount:      0,
    warnedThisIdle: false,  ; 今回の離席で警告済みかどうか
    entries:        [],     ; 当日のサボりログ（23時にファイルへ書き出し）
    lastPhase:      "",     ; 前回チェック時のフェーズ（lock突入検知用）
    lockStartTick:  0       ; 今回のlockフェーズが始まったTickCount
}

; ===== ログ保存先ディレクトリを作成（変更不要）=====
if !DirExist(saboLogDir)
    DirCreate(saboLogDir)

; ===== 起動時：前回の異常終了を記録（変更不要）=====
if FileExist(sentinelPath) {
    try {
        lastStart := Trim(FileRead(sentinelPath))
        interruptMins := DateDiff(A_Now, lastStart, "Minutes")
        if (interruptMins > 0 && interruptMins < 1440) {
            logDate  := FormatTime(lastStart, "yyyy-MM-dd")
            today    := FormatTime(, "yyyy-MM-dd")
            logPath  := saboLogDir "\" logDate "_sabo.txt"
            entry    := "・監視中断（異常終了）：約 " interruptMins " 分間"
            if (logDate = today) {
                ; 当日分はメモリに積む（23時にまとめて書き出す）
                sabo.entries.Push(entry)
            } else {
                ; 前日以前のものは直接ファイルへ追記
                FileAppend(entry "`n", logPath)
            }
        }
    }
}
try FileDelete(sentinelPath)
FileAppend(A_Now, sentinelPath)

; ===== 正常終了時に sentinel を削除（変更不要）=====
OnExit(LauncherCleanup)
LauncherCleanup(reason, code) {
    if (reason = "Reload")
        return
    global sentinelPath, discordWebhook
    try FileDelete(sentinelPath)
    ; WinHTTP で同期送信（PowerShell不要・OnExit内でも確実に動作）
    if (discordWebhook != "") {
        try {
            body := '{"content": "⚠️ 監視スクリプト (launcher.ahk) が終了しました。サボり検知が無効になっています。"}'
            http := ComObject("WinHttp.WinHttpRequest.5.1")
            http.Open("POST", discordWebhook, false)
            http.SetRequestHeader("Content-Type", "application/json")
            http.Send(body)
        }
    }
}

; ===== Discord 通知（変更不要）=====
SendDiscordAlert(msg) {
    global discordWebhook
    SendDiscordTo(discordWebhook, msg)
}

SendDiscord(msg) => SendDiscordAlert(msg)

SendDiscordTo(url, msg) {
    if (url = "")
        return
    try {
        safe := StrReplace(StrReplace(msg, '"', "'"), "`n", "\n")
        body := '{"content": "' safe '"}'
        http := ComObject("WinHttp.WinHttpRequest.5.1")
        http.Open("POST", url, false)
        http.SetRequestHeader("Content-Type", "application/json")
        http.Send(body)
    }
}
; ===== 離席検知：30秒ごとに監視（変更不要）=====
SetTimer(CheckAbsence, 30000)

CheckAbsence() {
    global sabo, absentThresholdMin, phaseFile, saboLogDir

    ; ロックフェーズ中のみ計測
    phase := ""
    try phase := Trim(SafeReadFile(phaseFile))
    if (phase != "lock") {
        ; 監視対象外フェーズに入ったら離席状態をリセット
        ; （運動・食事休憩・中休み・通常休憩中の無操作が復帰後にサボりとして誤記録されるのを防ぐ）
        sabo.isAbsent       := false
        sabo.warnedThisIdle := false
        sabo.absentStartMs  := 0
        sabo.lastPhase      := phase
        sabo.lockStartTick  := 0
        return
    }

    ; lock以外からlockに切り替わった瞬間を記録する。
    ; （休憩・昼休み・運動等の間に離席していた時間は、lock再開直後の
    ;   A_TimeIdlePhysical にそのまま残ってしまうため、これを差し引かないと
    ;   「休憩中に離席していた分」まで丸ごとサボりとして誤検知してしまう）
    if (sabo.lastPhase != "lock")
        sabo.lockStartTick := A_TickCount
    sabo.lastPhase := phase

    ; 実際の無操作時間のうち、「今回のlock開始以降」の分だけを対象にする
    idleMs      := Min(A_TimeIdlePhysical, A_TickCount - sabo.lockStartTick)
    warnMs      := (absentThresholdMin - 1) * 60000   ; 警告タイミング（閾値の1分前）
    thresholdMs := absentThresholdMin * 60000

    ; 警告通知（閾値1分前・1回のみ）
    if (!sabo.warnedThisIdle && idleMs >= warnMs && idleMs < thresholdMs) {
        sabo.warnedThisIdle := true
        TrayTip("⚠️ もうすぐサボり判定", "あと1分操作がないとサボりとして記録されます", "Mute")
        global saboWarnWebhook
        wh := (saboWarnWebhook != "") ? saboWarnWebhook : discordWebhook
        SendDiscordTo(wh, "⏰ **もうすぐサボり判定** - あと1分で記録されます（" FormatTime(, "HH:mm") "）")
    }

    ; 閾値到達 → 離席開始とみなす
    if (!sabo.isAbsent && idleMs >= thresholdMs) {
        sabo.isAbsent      := true
        sabo.absentStartMs := A_TickCount - idleMs
    }

    ; 復帰を検知 → ログに記録
    if (sabo.isAbsent && idleMs < thresholdMs) {
        saboMins := Max(1, Round((A_TickCount - sabo.absentStartMs) / 60000))
        sabo.isAbsent       := false
        sabo.warnedThisIdle := false
        sabo.saboCount      += 1

        ; ファイルには書かず、メモリに蓄積して23時にまとめて書き出す
        sabo.entries.Push("・サボり離席 " sabo.saboCount " 回目：約 " saboMins " 分")
        SendDiscord("🛋️ **サボり離席が検知されました（" sabo.saboCount " 回目）**`n約 " saboMins " 分間離席していました（" FormatTime(, "HH:mm") " 復帰）")
        return
    }

    ; 操作が再開されたら警告フラグをリセット
    if (idleMs < warnMs)
        sabo.warnedThisIdle := false
}

; ================================================================
; ★ 残業時間の計測（変更不要）
;
;    5秒ごとに以下を確認し、すべて満たす間だけ経過時間を加算する。
;      ・本日の work_goal.txt が「本日の dayId」かつ goalReached=1
;      ・current_phase.txt が lock / intermission ではない
;        （lock_window.ahk 側で計測中の時間と二重計上しないため）
;      ・対象ウィンドウがアクティブ、かつ無操作許容時間内
;
;    結果は overtime_work.txt に "dayId|残業ms" 形式で保存する
;    （dayId は上記の day_state.txt の値。カレンダー日付ではなく
;      「睡眠明けから次の睡眠明けまで」を1日とする区切り）。
;    dayId が変わったらメモリ上のカウンタは即座に0にリセットするが、
;    ファイルへの書き込みは「本日分の残業が実際に発生したとき」まで
;    遅延させる（日をまたいで作業を続けていた場合に、まだ lock_window.ahk
;    に読まれていない前日分をファイルごと消してしまわないため）。
;
;    このファイルは lock_window.ahk 起動時の翌日繰り越し計算でのみ
;    読み込まれる（launcher.ahk 側では読み込み後のリセット等は行わない）。
; ================================================================
global overtimeDayId     := currentDayId
global overtimeMs        := 0
global overtimeLastCheck := 0
try {
    _otInit := StrSplit(SafeReadFile(overtimeLogPath), "|")
    if (Integer(_otInit[1]) = currentDayId)
        overtimeMs := Integer(_otInit[2])
}

SetTimer(CheckOvertimeWork, 5000)

; ロック外での作業ウィンドウ判定（lock_window.ahk の IsWorkWindow() と同じロジック）
IsOvertimeWorkWindow() {
    global overtimeWorkWindowTitles, overtimeWorkWindowProcesses
    try {
        activeHwnd := WinGetID("A")
        if (!activeHwnd)
            return false
        title := WinGetTitle("ahk_id " activeHwnd)
        proc  := WinGetProcessName("ahk_id " activeHwnd)
        for kw in overtimeWorkWindowTitles {
            if InStr(title, kw)
                return true
        }
        for p in overtimeWorkWindowProcesses {
            if (StrLower(proc) = StrLower(p))
                return true
        }
    }
    return false
}

CheckOvertimeWork() {
    global overtimeMs, overtimeDayId, overtimeLastCheck, overtimeLogPath, currentDayId
    global overtimeIdleToleranceSecs, phaseFile, workGoalLogPath

    ; dayId（睡眠ベースの日付境界）が変わったら「メモリ上のカウンタ」だけリセットする（ファイルは触らない）。
    ; ここで overtime_work.txt を即座に上書きすると、日をまたいで作業を続けていた場合に
    ; まだ lock_window.ahk に読まれていない前日分の残業時間が消えてしまう。
    ; 本日分は goalReachedToday が true になって実際に加算が発生したときに、
    ; 下の書き込み処理で初めてファイルが「今日のdayId」で上書きされる。
    ; （本日分の書き込みが起きる＝本日すでに lock_window.ahk が起動してノルマを
    ;   達成済みということなので、その起動時点で前日分は既に読み取り済みのはずであり、
    ;   上書きしても前日分を消してしまう心配はない）
    if (currentDayId != overtimeDayId) {
        overtimeDayId     := currentDayId
        overtimeMs        := 0
        overtimeLastCheck := 0
    }

    ; 本日すでにノルマを達成しているか確認（work_goal.txt は lock_window.ahk が書き込む）
    goalReachedToday := false
    try {
        _wg := StrSplit(SafeReadFile(workGoalLogPath), "|")
        if (Integer(_wg[1]) = currentDayId && _wg.Length >= 3)
            goalReachedToday := (_wg[3] = "1")
    }
    if (!goalReachedToday) {
        overtimeLastCheck := 0   ; 未達成の間は経過時間を積み上げない
        return
    }

    ; lock_window.ahk が現在 lock / 中休み中なら、そちらで計測済みのため対象外
    ; （current_phase.txt が読めない＝lock_window.ahk が動いていない場合は "" 扱いになり対象になる）
    ; "lock_test" は右脳ドローイングのテスト実行中を示す値で、これも
    ; 残業として誤ってカウントしないよう対象外にする
    phaseNow := ""
    try phaseNow := Trim(SafeReadFile(phaseFile))
    if (phaseNow = "lock" || phaseNow = "intermission" || phaseNow = "lock_test") {
        overtimeLastCheck := 0
        return
    }

    if (!IsOvertimeWorkWindow()) {
        overtimeLastCheck := 0
        return
    }

    now    := A_TickCount
    idleMs := A_TimeIdlePhysical
    if (overtimeLastCheck > 0) {
        elapsed := now - overtimeLastCheck
        if (idleMs < overtimeIdleToleranceSecs * 1000)
            overtimeMs += elapsed
    }
    overtimeLastCheck := now

    SafeWriteFile(overtimeLogPath, currentDayId "|" overtimeMs)
}

; ================================================================
; ★ 待機中のトレイツールチップに「翌日のノルマ予測」を表示（変更不要）
;
;    本日すでにノルマを達成している場合、現時点までの残業時間をもとに
;    「今この瞬間に1日を終えたら、翌日のノルマは何時間何分になるか」を
;    15秒ごとに計算してツールチップに表示する。
;
;    計算式は lock_window.ahk 起動時の繰り越し計算と全く同じ:
;      超過分 = max(0, 本日の作業時間 - 本日の実効ノルマ) + 本日の残業時間
;      翌日のノルマ = max(workGoalMinMinutes, totalWorkGoalMinutes - 超過分)
;
;    カウントダウン中（作業開始まで／クロッキー開始まで）・就寝モード中は
;    そちらの表示を優先し、この更新は行わない。
;    ノルマ未達成、または本日分のデータがまだ無い場合は通常の
;    「Work Launcher - 待機中」のまま。
; ================================================================
SetTimer(UpdateIdleIconTip, 15000)

FormatMinutesHM(mins) {
    mins := Max(0, Round(mins))
    h := mins // 60
    m := Mod(mins, 60)
    if (h > 0)
        return h "時間" m "分"
    return m "分"
}

UpdateIdleIconTip() {
    global countdownEnd, nightModeActive, workGoalLogPath, overtimeLogPath, currentDayId
    global totalWorkGoalMinutes, workGoalMinMinutes

    ; カウントダウン中・就寝モード中はそちらの表示を優先し、何もしない
    if (nightModeActive)
        return
    if (countdownEnd > 0 && countdownEnd > A_TickCount)
        return

    goalReachedToday := false
    todayActiveMin    := 0
    todayEffGoalMin   := totalWorkGoalMinutes
    try {
        _wg := StrSplit(SafeReadFile(workGoalLogPath), "|")
        if (Integer(_wg[1]) = currentDayId && _wg.Length >= 3) {
            goalReachedToday := (_wg[3] = "1")
            todayActiveMin   := Round(Integer(_wg[2]) / 60000)
            todayEffGoalMin  := (_wg.Length >= 4) ? Integer(_wg[4]) : totalWorkGoalMinutes
        }
    }

    if (!goalReachedToday) {
        A_IconTip := "Work Launcher - 待機中"
        return
    }

    todayOvertimeMin := 0
    try {
        _ot := StrSplit(SafeReadFile(overtimeLogPath), "|")
        if (Integer(_ot[1]) = currentDayId)
            todayOvertimeMin := Round(Integer(_ot[2]) / 60000)
    }

    overMin       := Max(0, todayActiveMin - todayEffGoalMin) + todayOvertimeMin
    projectedGoal := Max(workGoalMinMinutes, totalWorkGoalMinutes - overMin)

    ; 「残業」として表示するのは、ロック中の超過分＋ロック外の残業分を合わせた合計
    ; （＝翌日のノルマ計算にそのまま使っている overMin と同じ値。内訳ではなく合計を見せる）
    A_IconTip := "Work Launcher - 待機中｜🎯ノルマ達成済み（残業"
        . FormatMinutesHM(overMin) "）｜今終えると翌日のノルマ: " FormatMinutesHM(projectedGoal)
}

; ===== スリープ解除時：前日ログをGUIで表示（変更不要）=====
ShowSaboLog() {
    global saboLogDir

    yesterday := FormatTime(DateAdd(A_Now, -1, "Days"), "yyyy-MM-dd")
    logPath   := saboLogDir "\" yesterday "_sabo.txt"

    if !FileExist(logPath)
        return

    logText := ""
    try logText := FileRead(logPath)
    if (Trim(logText) = "")
        return

    logGui := Gui("+AlwaysOnTop", yesterday " のサボりログ")
    logGui.SetFont("s10", "Segoe UI")
    logGui.BackColor := "1A1A2E"
    logGui.SetFont("s10 bold cWhite", "Segoe UI")
    logGui.Add("Text", "w320", yesterday " のサボり記録")
    logGui.SetFont("s9 cWhite", "Segoe UI")
    logGui.Add("Edit", "w320 h120 ReadOnly -E0x200 Background101020 cWhite", logText)
    logGui.SetFont("s9 c999999", "Segoe UI")
    logGui.Add("Text", "w320", "この内容を手動でDiscordに貼り付けてください。")
    logGui.Add("Button", "w320 y+8", "閉じる").OnEvent("Click", (*) => logGui.Destroy())
    logGui.Show("Center w340 NoActivate")
}
